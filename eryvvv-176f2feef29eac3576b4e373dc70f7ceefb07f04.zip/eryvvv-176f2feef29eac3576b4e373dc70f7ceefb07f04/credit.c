#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // prompt for card number
    long c;
    do
    {
        c = get_long("Card Number: ");
    }
    while (c < 0);

    // Count how many digits there are total
    int digits = 0;
    long check = c;
    while (check > 0)
    {
        check = check / 10;
        digits++;
    }

    // Isolate every other digit starting from second to the last and multiply by 2
    int d1 = ((c % 100) / 10) * 2;
    int d2 = ((c % 10000) / 1000) * 2;
    int d3 = ((c % 1000000) / 100000) * 2;
    int d4 = ((c % 100000000) / 10000000) * 2;
    int d5 = ((c % 10000000000) / 1000000000) * 2;
    int d6 = ((c % 1000000000000) / 100000000000) * 2;
    int d7 = ((c % 100000000000000) / 10000000000000) * 2;
    int d8 = ((c % 10000000000000000) / 1000000000000000) * 2;

    // Isolate the products and add the digits together
    int pd1 = (d1 % 10) + ((d1 % 100) / 10);
    int pd2 = (d2 % 10) + ((d2 % 100) / 10);
    int pd3 = (d3 % 10) + ((d3 % 100) / 10);
    int pd4 = (d4 % 10) + ((d4 % 100) / 10);
    int pd5 = (d5 % 10) + ((d5 % 100) / 10);
    int pd6 = (d6 % 10) + ((d6 % 100) / 10);
    int pd7 = (d7 % 10) + ((d7 % 100) / 10);
    int pd8 = (d8 % 10) + ((d8 % 100) / 10);

    // Add all the sums of the digits together
    int sum1 = (pd1 + pd2 + pd3 + pd4 + pd5 + pd6 + pd7 + pd8);

    // Isolate the other digits that remained from the original
    int od1 = (c % 10) / 1;
    int od2 = (c % 1000) / 100;
    int od3 = (c % 100000) / 10000;
    int od4 = (c % 10000000) / 1000000;
    int od5 = (c % 1000000000) / 100000000;
    int od6 = (c % 100000000000) / 10000000000;
    int od7 = (c % 10000000000000) / 1000000000000;
    int od8 = (c % 1000000000000000) / 100000000000000;

    // Add sum1 with the sum of all the digits that remained from the original
    int finalsum = (sum1 + od1 + od2 + od3 + od4 + od5 + od6 + od7 + od8);

    // Mark as invalid if not Visa, Amex, or Mastercard
    if (digits != 13 && digits != 15 && digits != 16)
    {
        printf("INVALID\n");
    }

    // Mark as invalid if not applicable to Algorithm
    else
    {
        if (finalsum % 10 != 0)
        {
            printf("INVALID\n");
        }
    }

    // Check if Mastercard by digit
    if (digits == 16 & finalsum % 10 == 0)
    {
        
        // Check if Mastercard 51, 52, 53, 54, 55
        if (d8 / 2 == 5)
        {
            if (od8 == 1 || od8 == 2 || od8 == 3 || od8 == 4 || od8 == 5)
            {
                printf("MASTERCARD\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else
        {
            
            // If correct digits but starts with 4, Visa
            if (d8 / 2 == 4)
            {
                printf("VISA\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
    }

    // Check if AMEX by digit
    if (digits == 15 && finalsum % 10 == 0)
    {
        
        // Check if starting with 34
        if (od8 == 3 && d7 / 2 == 4)
        {
            printf("AMEX\n");
        }
        else
        {
            
            // Check if starting with 37
            if (od8 == 3 && d7 / 2 == 7)
            {
                printf("AMEX\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
    }

    // Check if Visa by digit
    if (digits == 13 && finalsum % 10 == 0)
    {
        
        // Check if starting with 4
        if (od7 == 4)
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
}
